package demo.imphotelmanagement;

import java.util.ArrayList;

import demo.hotelmanagement.HotelRoom;

public interface ImDealsHotel {
	public void checkInRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> availableRoom);

	public void checkOutRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> unavailableRoom, int idRoom);
}
