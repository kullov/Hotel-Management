package demo.hotelmanagement;

public class Customer {
	private Person person;
	private int idRoom;
	
	public Customer() {
		super();
	}
	
	public Customer(Person person, int idRoom) {
		super();
		this.person = person;
		this.idRoom = idRoom;
	}

	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public int getIdRoom() {
		return idRoom;
	}
	public void setIdRoom(int idRoom) {
		this.idRoom = idRoom;
	}

	@Override
	public String toString() {
		return " \n Customer [" + person + ", id Room: " + idRoom + "]";
	}
	
}
