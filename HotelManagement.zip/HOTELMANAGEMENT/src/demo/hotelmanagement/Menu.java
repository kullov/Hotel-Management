package demo.hotelmanagement;

import demo.imphotelmanagement.ImpHashCode;

public class Menu implements ImpHashCode {
	public void menuMain() {
		System.out.println("Press key " + CASE_ADD_NEW_ROOM + " for enter a new hotel room");
		System.out.println("Press key " + CASE_SHOW_LIST_OF_HOTEL_ROOMS + "  for show list of hotel rooms");
		System.out.println("Press key " + CASE_SHOW_A_ROOM + " for show a room");
		System.out.println("Press key " + CASE_CHECKIN + " for check-in a hotel room");
		System.out.println("Press key " + CASE_CHECKOUT + " for check out a hotel room");
		System.out.println("Press key " + CASE_EXIT + " for exit this program");
	}

	public void menuCheckIn() {
		System.out.println("Press key " + CASE_SHOW_LIST_OF_AVAILABLE_ROOM + " for show list of available rooms");
		System.out.println("Press key " + CASE_CHECKIN_A_ROOM + " for check in a room");
		System.out.println("Press key " + CASE_SHOW_LIST_OF_UNAVAILABLE_ROOM + " for show list of unvailable rooms");
		System.out.println("Press key " + CASE_EXIT + " for exit");
	}

	public void menuManagerRooms() {
		System.out.println("Press key " + CASE_ADD_A_ROOM + " for add a hotel room");
		System.out.println("Press key " + CASE_DELETE_A_ROOM + " for delete a hotel room");
		System.out.println("Press key " + CASE_EDIT_A_ROOM + " for edit a hotel room");
		System.out.println("Press key " + CASE_EXIT + " for exit ");
	}

	public void menuManagerCusstomers() {
		System.out.println("Press key " + CASE_SHOW_LIST_OF_CUSTOMERS + " for show list of customers in this room");
		System.out.println("Press key " + CASE_ADD_A_CUSTOMER + " for add a customer");
		System.out.println("Press key " + CASE_DELETE_A_CUSTOMER + " for delete a customer");
		System.out.println("Press key " + CASE_EDIT_A_CUSTOMER + " for edit a customer");
		System.out.println("Press key " + CASE_EXIT + " for exit ");
	}
}
