package demo.hotelmanagement;

import java.util.ArrayList;
import java.util.Scanner;

import demo.imphotelmanagement.ImDealsHotel;
import demo.imphotelmanagement.ImpHashCode;

public class HotelManager implements ImDealsHotel, ImpHashCode {

	private ArrayList<HotelRoom> hotelRooms = new ArrayList<HotelRoom>();

	public static void main(String[] args) {
		HotelManager manager = new HotelManager();
		ArrayList<HotelRoom> availableRooms;
		ArrayList<HotelRoom> unavailableRooms;
		ArrayList<HotelRoom> hotelRooms = manager.hotelRooms;
		Scanner scan = new Scanner(System.in);
		Menu m = new Menu();
		int value = 0, idRoom = 0, identifyCard;
		String u = null;
		do {
			m.menuMain();
			System.out.println("Enter your request: ");
			try {
				value = Integer.parseInt(scan.nextLine());
			} catch (Exception e) {
				e.printStackTrace();
			}
			switch (value) {
			case CASE_EXIT:
				System.exit(CASE_EXIT);
				break;
			case CASE_ADD_NEW_ROOM:
				do {
					System.out.println("Enter a new hotel room: ");
					manager.addHotelRoom(hotelRooms);
					System.out.println("Do you want to enter a new hotel room? Y or N");
					try {
						u = scan.nextLine();
					} catch (Exception e) {
						e.printStackTrace();
					}
				} while (!u.equalsIgnoreCase("N"));
				break;
			case CASE_SHOW_LIST_OF_HOTEL_ROOMS:
				try {
					System.out.println("*** Show list of hotel rooms ***");
					manager.showHotelRooms(hotelRooms);
				} catch (NullPointerException e) {
					System.out.println(e);
				} catch (Exception e) {
					System.out.println(e);
				}
				do {
					m.menuManagerRooms();
					System.out.println("Enter key: ");
					try {
						value = Integer.parseInt(scan.nextLine());
					} catch (Exception e) {
						e.printStackTrace();
					}
					switch (value) {
					case CASE_ADD_A_ROOM:
						do {
							System.out.println("Enter a new hotel room: ");
							manager.addHotelRoom(hotelRooms);
							System.out.println("Do you want to enter a new hotel room? Y or N");
							try {
								u = scan.nextLine();
							} catch (Exception e) {
								e.printStackTrace();
							}
						} while (!u.equalsIgnoreCase("N"));
						break;
					case CASE_DELETE_A_ROOM:
						System.out.println("Enter id Room that you want to delete: ");
						try {
							idRoom = Integer.parseInt(scan.nextLine());
							manager.deleteAHotelRoom(hotelRooms, idRoom);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
					case CASE_EDIT_A_ROOM:
						System.out.println("Enter id Room that you want to edit: ");
						try {
							idRoom = Integer.parseInt(scan.nextLine());
						} catch (Exception e) {
							e.printStackTrace();
						}
						manager.editAHotelRoom(hotelRooms, idRoom);
						break;
					case CASE_EXIT:
						
						break;
					default:
						System.out.println("Availd!");
						break;
					}
					System.out.println("Do you want to continue case " + CASE_SHOW_LIST_OF_HOTEL_ROOMS + "? Y or N");
					try {
						u = scan.nextLine();
					} catch (Exception e) {
						e.printStackTrace();
					}
				} while (!u.equalsIgnoreCase("N"));
				break;
			case CASE_SHOW_A_ROOM:
				System.out.println("Enter ID Room that you want to show: ");
				try {
					idRoom = Integer.parseInt(scan.nextLine());
					manager.showARoom(hotelRooms, idRoom);
				} catch (Exception e) {
					e.printStackTrace();
				}
				do {
					m.menuManagerCusstomers();
					System.out.println("Enter key: ");
					try {
						value = Integer.parseInt(scan.nextLine());
					} catch (Exception e) {
						e.printStackTrace();
					}
					switch (value) {
					case CASE_SHOW_LIST_OF_CUSTOMERS:
						for (HotelRoom hotelRoom2 : hotelRooms) {
							if (idRoom == hotelRoom2.getIdRoom()) {
								manager.showCustomers(hotelRoom2.getCustomers());
							}
						}
						break;
					case CASE_ADD_A_CUSTOMER:
						for (HotelRoom hotelRoom2 : hotelRooms) {
							if (idRoom == hotelRoom2.getIdRoom()) {
								manager.addCustomer(hotelRoom2.getCustomers(), idRoom);
							}
						}
						break;
					case CASE_DELETE_A_CUSTOMER:
						try {
							System.out.println("Enter identifyCard that you want to delete: ");
							identifyCard = Integer.parseInt(scan.nextLine());
							for (HotelRoom hotelRoom2 : hotelRooms) {
								if (idRoom == hotelRoom2.getIdRoom()) {
									manager.deleteCustomer(hotelRoom2.getCustomers(), identifyCard);
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
					case CASE_EDIT_A_CUSTOMER:
						try {
							System.out.println("Enter identifyCard that you want to edit: ");
							identifyCard = Integer.parseInt(scan.nextLine());
							for (HotelRoom hotelRoom2 : hotelRooms) {
								if (idRoom == hotelRoom2.getIdRoom()) {
									manager.editCustomer(hotelRoom2.getCustomers(), identifyCard);
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
					case CASE_EXIT:
						break;
					default:
						System.out.println("Availd!");
						break;
					}
					System.out.println("Do you want to continue? Y or N");
					try {
						u = scan.nextLine();
					} catch (Exception e) {
						e.printStackTrace();
					}
				} while (!u.equalsIgnoreCase("N"));
				break;
			case CASE_CHECKIN:
				availableRooms = manager.enterAvailableRooms(hotelRooms);
				unavailableRooms = manager.enterUnavailableRooms(hotelRooms);
				do {
					m.menuCheckIn();
					System.out.println("Enter key: ");
					try {
						value = Integer.parseInt(scan.nextLine());
					} catch (Exception e) {
						e.printStackTrace();
					}
					switch (value) {
					case CASE_EXIT:
						break;
					case CASE_SHOW_LIST_OF_AVAILABLE_ROOM:
						try {
							availableRooms = manager.enterAvailableRooms(hotelRooms);
							System.out.println("Show list of available room: ");
							manager.showHotelRooms(availableRooms);
						} catch (NullPointerException e) {
							System.out.println(e);
						} catch (Exception e) {
							System.out.println(e);
						}
						break;
					case CASE_CHECKIN_A_ROOM:
						do {
							availableRooms = manager.enterAvailableRooms(hotelRooms);
							System.out.println("Check-in a hotel room: ");
							System.out.println("List of available rooms: ");
							for (int i = 0; i < availableRooms.size(); i++) {
								System.out.print(availableRooms.get(i).getIdRoom() + "\t");
							}
							manager.checkInRoom(hotelRooms, availableRooms);

							System.out.println("Do you want to checkin another hotel room? Y or N");
							try {
								u = scan.nextLine();
							} catch (Exception e) {
								e.printStackTrace();
							}
						} while (!u.equalsIgnoreCase("N"));
						break;
					case CASE_SHOW_LIST_OF_UNAVAILABLE_ROOM:
						try {
							unavailableRooms = manager.enterUnavailableRooms(hotelRooms);
							System.out.println("Show list of unavailable room: ");
							manager.showHotelRooms(unavailableRooms);
						} catch (NullPointerException e) {
							System.out.println(e);
						} catch (Exception e) {
							System.out.println(e);
						}
						break;
					}
					System.out.println("Do you want to continue case " + CASE_CHECKIN + "? Y or N");
					try {
						u = scan.nextLine();
					} catch (Exception e) {
						e.printStackTrace();
					}
				} while (!u.equalsIgnoreCase("N"));

				break;
			case CASE_CHECKOUT:
				System.out.println("Check out a room: ");
				do {
					try {
						unavailableRooms = manager.enterUnavailableRooms(hotelRooms);
						for (int i = 0; i < unavailableRooms.size(); i++) {
							System.out.print(unavailableRooms.get(i).getIdRoom() + "\t");
						}
						System.out.println("Enter idRoom that you want to checkout: ");
						try {
							idRoom = Integer.parseInt(scan.nextLine());
						} catch (Exception e) {
							e.printStackTrace();
						}
						manager.checkOutRoom(hotelRooms, unavailableRooms, idRoom);
					} catch (NullPointerException e) {
						System.out.println(e);
					} catch (Exception e) {
						System.out.println(e);
					}
					System.out.println("Do you want to checkout another hotel room? Y or N");
					try {
						u = scan.nextLine();
					} catch (Exception e) {
						e.printStackTrace();
					}
				} while (!u.equalsIgnoreCase("N"));
				break;
			default:
				System.out.println("Availd!");
				break;
			}
			System.out.println("Do you want to continue this programe? Y or N");
			try {
				u = scan.nextLine();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} while (!u.equalsIgnoreCase("N"));
	}

	private void editAHotelRoom(ArrayList<HotelRoom> hotelRooms2, int idRoom) {
		Scanner scan = new Scanner(System.in);
		for (int i = 0; i < hotelRooms2.size(); i++) {
			if (idRoom == hotelRooms2.get(i).getIdRoom()) {
				System.out.println("Edit room " + hotelRooms2.get(i).getIdRoom() + ": ");
				System.out.println("**************************************************");
				System.out.println("Edit price: ");
				hotelRooms2.get(i).setPrice(Double.parseDouble(scan.nextLine()));
				System.out.println("Edit number of days rented: ");
				hotelRooms2.get(i).setNumberOfDaysRented(Integer.parseInt(scan.nextLine()));
				System.out.println("Edit number of customer: ");
				hotelRooms2.get(i).setNumberOfPeople(Integer.parseInt(scan.nextLine()));
			}
		}
	}

	private void editCustomer(ArrayList<Customer> customers, int identifyCard) {
		Scanner scan = new Scanner(System.in);
		for (int i = 0; i < customers.size(); i++) {
			if (identifyCard == customers.get(i).getPerson().getIdentifyCard()) {
				System.out.println("Edit customer: ");
				System.out.println("**************************************************");
				System.out.println("Edit name: ");
				customers.get(i).getPerson().setName(scan.nextLine());
				System.out.println("Edit age: ");
				customers.get(i).getPerson().setAge(Integer.parseInt(scan.nextLine()));
				System.out.println("Edit address: ");
				customers.get(i).getPerson().setAddress(enterAdress());
			}
		}
	}

	private void deleteCustomer(ArrayList<Customer> customers, int identifyCard) {
		for (int i = 0; i < customers.size(); i++) {
			if (identifyCard == customers.get(i).getPerson().getIdentifyCard()) {
				customers.remove(i);
				System.out.println("Deleted!");
			}
		}
	}

	private void showARoom(ArrayList<HotelRoom> hotelRooms, int idRoom) {
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (idRoom == hotelRooms.get(i).getIdRoom()) {
				System.out.println("******************************************************");
				System.out.println("ID of room: " + hotelRooms.get(i).getIdRoom());
				System.out.println("Type room: " + hotelRooms.get(i).getTypeRoom());
				System.out.println("Price: " + hotelRooms.get(i).getPrice());
				System.out.println("Number of days rented: " + hotelRooms.get(i).getNumberOfDaysRented());
				System.out.println("Number of customer: " + hotelRooms.get(i).getNumberOfPeople());
				System.out.println("Status: " + hotelRooms.get(i).getStatus());
				if (hotelRooms.get(i).getCustomers() != null) {
					System.out.println("List Customer: " + hotelRooms.get(i).listCustomers());
				}
				System.out.println("******************************************************");
			}
		}
	}

	private void addCustomer(ArrayList<Customer> customers, int idRoom) {
		Customer customer = new Customer();
		customer = enterCustomer(idRoom);
		customers.add(customer);
	}

	private ArrayList<HotelRoom> addHotelRoom(ArrayList<HotelRoom> hotelRooms) {
		HotelRoom hotelRoom = enterRoom(null);
		hotelRooms.add(hotelRoom);
		return hotelRooms;
	}

	private void deleteAHotelRoom(ArrayList<HotelRoom> hotelRooms, int idRoom) {
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (idRoom == hotelRooms.get(i).getIdRoom()) {
				hotelRooms.remove(i);
				System.out.println("Delete successfull!");
			}
		}
	}

	private Person enterPerson() {
		Scanner scan = new Scanner(System.in);
		Person person = new Person();
		System.out.println("***");
		try {
			System.out.println("Enter name: ");
			person.setName(scan.nextLine());
			System.out.println("Enter age: ");
			person.setAge(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter DOB: ");
			person.setDOB(scan.nextLine());
			System.out.println("Enter Identify Card: 	");
			person.setIdentifyCard(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter address: ");
			person.setAddress(enterAdress());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return person;
	}

	private Address enterAdress() {
		Scanner scan = new Scanner(System.in);
		Address address = new Address();
		System.out.println("***");
		try {
			System.out.println("Enter number of house: ");
			address.setNumberOfHouse(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter alley: ");
			address.setAlley(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter lane: ");
			address.setLane(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter street: ");
			address.setStreet(scan.nextLine());
			System.out.println("Enter subDistrict: ");
			address.setSubDistrict(scan.nextLine());
			System.out.println("Enter district: ");
			address.setDistrict(scan.nextLine());
			System.out.println("Enter city: ");
			address.setCity(scan.nextLine());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return address;
	}

	private Customer enterCustomer(int idRoom) {
		Customer customer = new Customer();
		customer.setPerson(enterPerson());
		customer.setIdRoom(idRoom);
		return customer;
	}

	private ArrayList<Customer> enterCustomers(int idRoom) {
		String u = null;
		Scanner scan = new Scanner(System.in);
		Customer customer;
		ArrayList<Customer> customers = new ArrayList<Customer>();
		do {
			customer = enterCustomer(idRoom);
			customers.add(customer);
			System.out.println("Do you want to add more customer? Y or N");
			try {
				u = scan.nextLine();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} while (!u.equalsIgnoreCase("N"));
		return customers;
	}

	private HotelRoom enterRoom(ArrayList<Customer> customers) {
		int typeRoom = 0;
		boolean flag = true;
		Scanner scan = new Scanner(System.in);
		HotelRoom hotelRoom = new HotelRoom();

		System.out.println("***");
		do {
			System.out.println("Enter type of room: ");
			System.out.println("Press '1' : VIP room || '0' : Normal room");
			try {
				typeRoom = Integer.parseInt(scan.nextLine());
			} catch (Exception e) {
				e.printStackTrace();
			}
			switch (typeRoom) {
			case 0:
				hotelRoom.setTypeRoom("VIP Room");
				flag = false;
				break;
			case 1:
				hotelRoom.setTypeRoom("Normal Room");
				flag = false;
			default:
				break;
			}
		} while (flag);
		try {
			System.out.println("Enter id of room: ");
			hotelRoom.setIdRoom(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter price: ");
			hotelRoom.setPrice(Double.parseDouble(scan.nextLine()));
			System.out.println("Enter number of days rented: ");
			hotelRoom.setNumberOfDaysRented(Double.parseDouble(scan.nextLine()));
			System.out.println("Enter number of people: ");
			hotelRoom.setNumberOfPeople(Integer.parseInt(scan.nextLine()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		hotelRoom.setCustomers(customers);
		if (hotelRoom.getCustomers() == null) {
			hotelRoom.setStatus("Available");
		} else {
			hotelRoom.setStatus("Unavailable");
		}
		return hotelRoom;
	}

	public void showHotelRooms(ArrayList<HotelRoom> hotelRooms) {
		for (int i = 0; i < hotelRooms.size(); i++) {
			System.out.println("******************************************************");
			System.out.println("Id of room: " + hotelRooms.get(i).getIdRoom());
			System.out.println("Type room: " + hotelRooms.get(i).getTypeRoom());
			System.out.println("Price: " + hotelRooms.get(i).getPrice());
			System.out.println("Number of days rented: " + hotelRooms.get(i).getNumberOfDaysRented());
			System.out.println("Number of customer: " + hotelRooms.get(i).getNumberOfPeople());
			System.out.println("Status: " + hotelRooms.get(i).getStatus());
			if (hotelRooms.get(i).getCustomers() != null) {
				System.out.println("List Customer: " + hotelRooms.get(i).listCustomers());
			}
			System.out.println("******************************************************");
		}
	}

	public void showCustomers(ArrayList<Customer> customers) {
		for (Customer customer : customers) {
			System.out.println(customer.toString() + "\n");
		}
	}

	private ArrayList<HotelRoom> enterAvailableRooms(ArrayList<HotelRoom> hotelRooms) {
		ArrayList<HotelRoom> availableRooms = new ArrayList<>();
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (hotelRooms.get(i).getCustomers() == null) {
				availableRooms.add(hotelRooms.get(i));
			}
		}
		for (int i = 0; i < availableRooms.size(); i++) {
			if (availableRooms.get(i).getCustomers() != null) {
				availableRooms.remove(i);
			}
		}
		return availableRooms;
	}

	private ArrayList<HotelRoom> enterUnavailableRooms(ArrayList<HotelRoom> hotelRooms) {
		ArrayList<HotelRoom> unavailableRooms = new ArrayList<HotelRoom>();
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (hotelRooms.get(i).getCustomers() != null) {
				unavailableRooms.add(hotelRooms.get(i));
			}
		}
		for (int i = 0; i < unavailableRooms.size(); i++) {
			if (unavailableRooms.get(i).getCustomers() == null) {
				unavailableRooms.remove(i);
			}
		}
		return unavailableRooms;
	}

	@Override
	public void checkInRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> availableRooms) {
		Scanner scan = new Scanner(System.in);
		int idRoom = 0;
		ArrayList<Customer> customers = new ArrayList<Customer>();

		System.out.println("Choose 1 available room: ");
		try {
			idRoom = Integer.parseInt(scan.nextLine());
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (int i = 0; i < availableRooms.size(); i++) {
			if (idRoom == availableRooms.get(i).getIdRoom()) {
				customers = enterCustomers(idRoom);
				availableRooms.get(i).setCustomers(customers);
				availableRooms.get(i).setStatus("Unavailable!");
			}
		}
		for (int j = 0; j < hotelRooms.size(); j++) {
			if (hotelRooms.get(j).getIdRoom() == idRoom) {
				hotelRooms.get(j).setCustomers(customers);
				hotelRooms.get(j).setStatus("Unavailable!");

			}
		}
	}

	@Override
	public void checkOutRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> unavailableRoom, int idRoom) {
		for (int i = 0; i < unavailableRoom.size(); i++) {
			if (idRoom == unavailableRoom.get(i).getIdRoom()) {
				unavailableRoom.get(i).setCustomers(null);
				unavailableRoom.get(i).setStatus(null);
			}
		}
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (hotelRooms.get(i).getIdRoom() == idRoom) {
				hotelRooms.get(i).setCustomers(null);
				hotelRooms.get(i).setStatus("Available!");
			}
		}

	}
}
