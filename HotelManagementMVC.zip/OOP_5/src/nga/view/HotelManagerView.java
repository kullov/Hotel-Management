package nga.view;

import java.util.ArrayList;
import java.util.Scanner;

import nga.entity.Address;
import nga.entity.Customer;
import nga.entity.HotelRoom;
import nga.entity.Person;

public class HotelManagerView {
	public Person enterPerson() {
		Scanner scan = new Scanner(System.in);
		Person person = new Person();
		System.out.println("***");
		try {
			System.out.println("Enter name: ");
			person.setName(scan.nextLine());
			System.out.println("Enter age: ");
			person.setAge(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter DOB: ");
			person.setDOB(scan.nextLine());
			System.out.println("Enter Identify Card: ");
			person.setIdentifyCard(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter address: ");
			person.setAddress(enterAdress());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return person;
	}

	public Address enterAdress() {
		Scanner scan = new Scanner(System.in);
		Address address = new Address();
		System.out.println("***");
		try {
			System.out.println("Enter number of house: ");
			address.setNumberOfHouse(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter alley: ");
			address.setAlley(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter lane: ");
			address.setLane(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter street: ");
			address.setStreet(scan.nextLine());
			System.out.println("Enter subDistrict: ");
			address.setSubDistrict(scan.nextLine());
			System.out.println("Enter district: ");
			address.setDistrict(scan.nextLine());
			System.out.println("Enter city: ");
			address.setCity(scan.nextLine());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return address;
	}

	public ArrayList<Customer> enterCustomers(int idRoom) {
		String u = null;
		Scanner scan = new Scanner(System.in);
		Customer customer;
		ArrayList<Customer> customers = new ArrayList<Customer>();
		do {
			customer = enterCustomer(idRoom);
			customers.add(customer);
			System.out.println("Do you want to add more customer? Y or N");
			try {
				u = scan.nextLine();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} while (!u.equalsIgnoreCase("N"));
		return customers;
	}

	public Customer enterCustomer(int idRoom) {
		Customer customer = new Customer();
		customer.setPerson(enterPerson());
		customer.setIdRoom(idRoom);
		return customer;
	}

	public HotelRoom enterRoom(ArrayList<Customer> customers) {
		int typeRoom = 0;
		Scanner scan = new Scanner(System.in);
		HotelRoom hotelRoom = new HotelRoom();
		boolean flag = true;
		System.out.println("***");
		do {
			System.out.println("Enter type of room: ");
			System.out.println("Press '1' : VIP room || '0' : Normal room");
			try {
				typeRoom = Integer.parseInt(scan.nextLine());
			} catch (Exception e) {
				e.printStackTrace();
			}
			switch (typeRoom) {
			case 0:
				hotelRoom.setTypeRoom("VIP Room");
				flag = false;
				break;
			case 1:
				hotelRoom.setTypeRoom("Normal Room");
				flag = false;
			default:
				break;
			}
		} while (flag);
		try {
			System.out.println("Enter id of room: ");
			hotelRoom.setIdRoom(Integer.parseInt(scan.nextLine()));
			System.out.println("Enter price: ");
			hotelRoom.setPrice(Double.parseDouble(scan.nextLine()));
			System.out.println("Enter number of days rented: ");
			hotelRoom.setNumberOfDaysRented(Double.parseDouble(scan.nextLine()));
			System.out.println("Enter number of people: ");
			hotelRoom.setNumberOfPeople(Integer.parseInt(scan.nextLine()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		hotelRoom.setCustomers(customers);
		if (hotelRoom.getCustomers() == null) {
			hotelRoom.setStatus("Available");
		} else {
			hotelRoom.setStatus("Unavailable");
		}
		return hotelRoom;
	}

	public HotelRoom editRoom(int idRoom) {
		boolean flag = true;
		Scanner scan = new Scanner(System.in);
		HotelRoom hotelRoom = new HotelRoom();
		int typeRoom = 0;
		System.out.println("Edit room " + idRoom + ": ");
		System.out.println("**************************************************");
		System.out.println("***");
		do {
			System.out.println("Edit type of room: ");
			System.out.println("Press '1' : VIP room || '0' : Normal room");
			try {
				typeRoom = Integer.parseInt(scan.nextLine());
			} catch (Exception e) {
				e.printStackTrace();
			}
			switch (typeRoom) {
			case 0:
				hotelRoom.setTypeRoom("VIP Room");
				flag = false;
				break;
			case 1:
				hotelRoom.setTypeRoom("Normal Room");
				flag = false;
			default:
				break;
			}
		} while (flag);
		
		System.out.println("Edit price: ");
		 hotelRoom.setPrice(Double.parseDouble(scan.nextLine()));
		System.out.println("Edit number of days rented: ");
		 hotelRoom.setNumberOfDaysRented(Integer.parseInt(scan.nextLine()));
		System.out.println("Edit number of customer: ");
		hotelRoom.setNumberOfPeople(Integer.parseInt(scan.nextLine()));
		return hotelRoom;
	}
	
	public int getIdRoomFromKeyBoard() {
		int idRoom = 0;
		Scanner scan = new Scanner(System.in);
		
		try {
			idRoom = Integer.parseInt(scan.nextLine());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return idRoom;
	}
	public int getValueFromKeyBoard() {
		int value = 0;
		Scanner scan = new Scanner(System.in);
		try {
			value = Integer.parseInt(scan.nextLine());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}
	public String getStringFromKeyBoard() {
		Scanner scan = new Scanner(System.in);
		String str = null;
		try {
			str = scan.nextLine();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}
	public void showHotelRooms(ArrayList<HotelRoom> hotelRooms) {
		for (int i = 0; i < hotelRooms.size(); i++) {
			System.out.println("******************************************************");
			System.out.println("Id of room: " + hotelRooms.get(i).getIdRoom());
			System.out.println("Type room: " + hotelRooms.get(i).getTypeRoom());
			System.out.println("Price: " + hotelRooms.get(i).getPrice());
			System.out.println("Number of days rented: " + hotelRooms.get(i).getNumberOfDaysRented());
			System.out.println("Number of customer: " + hotelRooms.get(i).getNumberOfPeople());
			System.out.println("Status: " + hotelRooms.get(i).getStatus());
			if (hotelRooms.get(i).getCustomers() != null) {
				System.out.println("List Customer: " + hotelRooms.get(i).listCustomers());
			}
			System.out.println("******************************************************");
		}
	}

	public void showCustomers(ArrayList<Customer> customers) {
		for (Customer customer : customers) {
			System.out.println(customer.toString() + "\n");
		}
	}

	public void showARoom(ArrayList<HotelRoom> hotelRooms, int idRoom) {
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (idRoom == hotelRooms.get(i).getIdRoom()) {
				System.out.println("******************************************************");
				System.out.println("ID of room: " + hotelRooms.get(i).getIdRoom());
				System.out.println("Type room: " + hotelRooms.get(i).getTypeRoom());
				System.out.println("Price: " + hotelRooms.get(i).getPrice());
				System.out.println("Number of days rented: " + hotelRooms.get(i).getNumberOfDaysRented());
				System.out.println("Number of customer: " + hotelRooms.get(i).getNumberOfPeople());
				System.out.println("Status: " + hotelRooms.get(i).getStatus());
				if (hotelRooms.get(i).getCustomers() != null) {
					System.out.println("List Customer: " + hotelRooms.get(i).listCustomers());
				}
				System.out.println("******************************************************");
			}
		}
	}

	public void printMessage(String message) {
		System.out.println(message);
	}
}
