package nga.entity;

public class Person {
	private String name;
	private int age;
	private String DOB;
	private int identifyCard;
	private Address address;
	
	public Person() {
		super();
	}
	public Person(String name, int age, String dOB, int identifyCard, Address address) {
		super();
		this.name = name;
		this.age = age;
		DOB = dOB;
		this.identifyCard = identifyCard;
		this.address = address;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public int getIdentifyCard() {
		return identifyCard;
	}
	public void setIdentifyCard(int identifyCard) {
		this.identifyCard = identifyCard;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "[Name: " + name + ", age: " + age + ", DOB: " + DOB + ", Identify Card: " + identifyCard
				+ ", address: " + address + "]";
	}
	
}
