package nga.entity;

import java.util.ArrayList;

public class HotelRoom {
	private String typeRoom;
	private int idRoom;
	private double price;
	private double numberOfDaysRented;
	private int numberOfPeople;
	private ArrayList<Customer> customers;
	private String status;
	public HotelRoom() {
		super();
	}
	public HotelRoom(String typeRoom, int idRoom, double price, double numberOfDaysRented, int numberOfPeople, ArrayList<Customer> customers, String status) {
		super();
		this.idRoom = idRoom;
		this.typeRoom = typeRoom;
		this.price = price;
		this.numberOfDaysRented = numberOfDaysRented;
		this.numberOfPeople = numberOfPeople;
		this.customers = customers;
		this.status = status;
	}
	public String getTypeRoom() {
		return typeRoom;
	}
	public void setTypeRoom(String typeRoom) {
		this.typeRoom = typeRoom;
	}
	
	public int getIdRoom() {
		return idRoom;
	}
	public void setIdRoom(int idRoom) {
		this.idRoom = idRoom;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getNumberOfDaysRented() {
		return numberOfDaysRented;
	}
	public void setNumberOfDaysRented(double numberOfDaysRented) {
		this.numberOfDaysRented = numberOfDaysRented;
	}
	public int getNumberOfPeople() {
		return numberOfPeople;
	}
	public void setNumberOfPeople(int numberOfPeople) {
		this.numberOfPeople = numberOfPeople;
	}
	
	public ArrayList<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(ArrayList<Customer> customers) {
		this.customers = customers;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String listCustomers( ) {
		ArrayList<Customer> customers = this.customers;
		String re = "";
		for (Customer customer : customers) {
			re += customer.toString() + "\n";	
		}
		return re;
	}
	@Override
	public String toString() {
		return "\n [Type Room: " + typeRoom + ", id : "+ idRoom + ", price: " + price + ", numberOfDaysRented: " + numberOfDaysRented
				+ ", numberOfPeople: " + numberOfPeople + ", status: " + status +", customers: " + "\n"+ listCustomers() +  "]";
	}
	
}
