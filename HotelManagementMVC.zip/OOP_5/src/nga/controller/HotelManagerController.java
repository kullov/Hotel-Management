package nga.controller;

import java.util.ArrayList;

import nga.entity.HotelRoom;
import nga.imp.ImpHashCode;
import nga.model.HotelManagerModel;
import nga.view.HotelManagerView;
import nga.view.Menu;

public class HotelManagerController implements ImpHashCode {
	private static HotelManagerModel model;
	private static HotelManagerView view;

	public static void main(String[] args) {
		model = new HotelManagerModel();
		view = new HotelManagerView();
		ArrayList<HotelRoom> availableRooms;
		ArrayList<HotelRoom> unavailableRooms;
		ArrayList<HotelRoom> hotelRooms = new ArrayList<HotelRoom>();
		Menu m = new Menu();
		int value = 0, idRoom = 0, identifyCard;
		String str = null;
		do {
			m.menuMain();
			view.printMessage("Enter value: ");
			value = view.getValueFromKeyBoard();
			switch (value) {
			case CASE_EXIT:
				System.exit(CASE_EXIT);
				break;
			case CASE_ADD_NEW_ROOM:
				do {
					view.printMessage("Enter a new hotel room: ");
					if (model.addHotelRoom(hotelRooms, view.enterRoom(null)) == true) {
						view.printMessage("Add successfull!");
					} else {
						view.printMessage("Add failed!");
					}
					view.printMessage("Do you want to enter a new hotel room? Y or N");
					str = view.getStringFromKeyBoard();
				} while (!str.equalsIgnoreCase("N"));
				break;
			case CASE_SHOW_LIST_OF_HOTEL_ROOMS:
				do {
				try {
					view.printMessage("*** Show list of hotel rooms ***");
					view.showHotelRooms(hotelRooms);
				} catch (NullPointerException e) {
					System.out.println(e);
				} catch (Exception e) {
					System.out.println(e);
				}
					m.menuManagerRooms();
					view.printMessage("Enter value: ");
					value = view.getValueFromKeyBoard();
					switch (value) {
					case CASE_ADD_A_ROOM:
						do {
							view.printMessage("Enter a new hotel room: ");
							if (model.addHotelRoom(hotelRooms, view.enterRoom(null)) == true) {
								view.printMessage("Add sucssessfull!");
							} else {
								view.printMessage("Add failed!");
							}
							view.printMessage("Do you want to enter a new hotel room? Y or N");
							str = view.getStringFromKeyBoard();
						} while (!str.equalsIgnoreCase("N"));
						break;
					case CASE_DELETE_A_ROOM:
						view.printMessage("Enter ID Room that you want to delete: ");
						idRoom = view.getIdRoomFromKeyBoard();
						if (model.deleteAHotelRoom(hotelRooms, idRoom) == true) {
							view.printMessage("Delete successfull!");
						} else {
							view.printMessage("Delete failed!");
						}
						break;
					case CASE_EDIT_A_ROOM:
						view.printMessage("Enter ID Room that you want to edit: ");
						idRoom = view.getIdRoomFromKeyBoard();
						model.editAHotelRoom(hotelRooms, view.editRoom(idRoom));
						break;
					case CASE_EXIT:
						break;
					default:
						view.printMessage("Availd!");
						break;
					}
					view.printMessage("Do you want to continue case " + CASE_SHOW_LIST_OF_HOTEL_ROOMS + "? Y or N");
					str = view.getStringFromKeyBoard();
				} while (!str.equalsIgnoreCase("N"));
				break;
			case CASE_SHOW_A_ROOM:
				view.printMessage("Enter ID Room that you want to show: ");
				idRoom = view.getIdRoomFromKeyBoard();
				do {
					m.menuManagerCusstomers();
					view.printMessage("Enter value: ");
					value = view.getValueFromKeyBoard();
					switch (value) {
					case CASE_SHOW_LIST_OF_CUSTOMERS:
						for (HotelRoom hotelRoom2 : hotelRooms) {
							if (idRoom == hotelRoom2.getIdRoom()) {
								view.showCustomers(hotelRoom2.getCustomers());
							}
						}
						break;
					case CASE_ADD_A_CUSTOMER:
						for (HotelRoom hotelRoom2 : hotelRooms) {
							if (idRoom == hotelRoom2.getIdRoom()) {
								if (model.addCustomer(hotelRoom2.getCustomers(), view.enterCustomer(idRoom)) == true) {
									view.printMessage("Add successfull!");
								} else {
									view.printMessage("Add failed!");
								}
							}
						}
						break;
					case CASE_DELETE_A_CUSTOMER:
						System.out.println("Enter identifyCard of the customer that you want to delete: ");
						identifyCard = view.getValueFromKeyBoard();
						for (HotelRoom hotelRoom2 : hotelRooms) {
							if (idRoom == hotelRoom2.getIdRoom()) {
								if (model.deleteCustomer(hotelRoom2.getCustomers(), identifyCard) == true) {
									view.printMessage("Delete successfull!");
								} else {
									view.printMessage("Delete failed!");
								}
							}
						}
						break;
					case CASE_EDIT_A_CUSTOMER:
						view.printMessage("Enter identifyCard that you want to edit: ");
						identifyCard = view.getValueFromKeyBoard();
						for (HotelRoom hotelRoom2 : hotelRooms) {
							if (idRoom == hotelRoom2.getIdRoom()) {
								model.editCustomer(hotelRoom2.getCustomers(), view.enterCustomer(idRoom));
								view.printMessage("Edit successfull!");
							} else {
								view.printMessage("Edit failed!");
							}
						}
						break;
					case CASE_EXIT:
						break;
					default:
						view.printMessage("Availd!");
						break;
					}
					view.printMessage("Do you want to continue? Y or N");
					str = view.getStringFromKeyBoard();
				} while (!str.equalsIgnoreCase("N"));
				break;
			case CASE_CHECKIN:
				availableRooms = model.enterAvailableRooms(hotelRooms);
				unavailableRooms = model.enterUnavailableRooms(hotelRooms);
				do {
					m.menuCheckIn();
					view.printMessage("Enter value: ");
					value = view.getValueFromKeyBoard();
					switch (value) {
					case CASE_EXIT:
						break;
					case CASE_SHOW_LIST_OF_AVAILABLE_ROOM:
						try {
							availableRooms = model.enterAvailableRooms(hotelRooms);
							view.printMessage("Show list of available room: ");
							view.showHotelRooms(availableRooms);
						} catch (NullPointerException e) {
							System.out.println(e);
						} catch (Exception e) {
							System.out.println(e);
						}
						break;
					case CASE_CHECKIN_A_ROOM:
						do {
							availableRooms = model.enterAvailableRooms(hotelRooms);
							view.printMessage("Check-in a hotel room: ");
							view.printMessage("List of available rooms: ");
							for (int i = 0; i < availableRooms.size(); i++) {
								System.out.print(availableRooms.get(i).getIdRoom() + "\t");
							}
							System.out.println("Choose 1 available room: ");
							idRoom = view.getIdRoomFromKeyBoard();
							if (model.checkInRoom(hotelRooms, availableRooms, idRoom) == true) {
								view.printMessage("Successfull!");
							} else {
								view.printMessage("Failed!");
							}
							view.printMessage("Do you want to checkin another hotel room? Y or N");
							str = view.getStringFromKeyBoard();
						} while (!str.equalsIgnoreCase("N"));
						break;
					case CASE_SHOW_LIST_OF_UNAVAILABLE_ROOM:
						try {
							unavailableRooms = model.enterUnavailableRooms(hotelRooms);
							view.printMessage("Show list of unavailable room: ");
							view.showHotelRooms(unavailableRooms);
						} catch (NullPointerException e) {
							System.out.println(e);
						} catch (Exception e) {
							System.out.println(e);
						}
						break;
					}
					view.printMessage("Do you want to continue case " + CASE_CHECKIN + "? Y or N");
					str = view.getStringFromKeyBoard();
				} while (!str.equalsIgnoreCase("N"));

				break;
			case CASE_CHECKOUT:
				view.printMessage("Check out a room: ");
				do {
					try {
						view.printMessage("List of unavailable rooms: ");
						unavailableRooms = model.enterUnavailableRooms(hotelRooms);
						for (int i = 0; i < unavailableRooms.size(); i++) {
							view.printMessage(unavailableRooms.get(i).getIdRoom() + "\t");
						}
						view.printMessage("Enter ID Room that you want to checkout: ");
						idRoom = view.getIdRoomFromKeyBoard();
						if (model.checkOutRoom(hotelRooms, unavailableRooms, idRoom) == true) {
							view.printMessage("Successfull!");
						} else {
							view.printMessage("Failed!");
						}
					} catch (NullPointerException e) {
						System.out.println(e);
					} catch (Exception e) {
						System.out.println(e);
					}
					view.printMessage("Do you want to checkout another hotel room? Y or N");
					str = view.getStringFromKeyBoard();
				} while (!str.equalsIgnoreCase("N"));
				break;
			default:
				view.printMessage("Availd!");
				break;
			}
			view.printMessage("Do you want to continue this programe? Y or N");
			str = view.getStringFromKeyBoard();
		} while (!str.equalsIgnoreCase("N"));
	}

}
