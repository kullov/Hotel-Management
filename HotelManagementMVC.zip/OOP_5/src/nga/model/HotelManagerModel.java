package nga.model;

import java.util.ArrayList;

import nga.entity.Customer;
import nga.entity.HotelRoom;
import nga.imp.ImDealsHotel;
import nga.imp.ImpHashCode;
import nga.view.HotelManagerView;

public class HotelManagerModel implements ImDealsHotel, ImpHashCode {
	private HotelManagerView view = new HotelManagerView();

	public boolean addCustomer(ArrayList<Customer> customers, Customer customer) {
		int size = customers.size();
		customers.add(customer);
		if (customers.size() == (size + 1))
			return true;
		return false;
	}

	public boolean addHotelRoom(ArrayList<HotelRoom> hotelRooms, HotelRoom hotelRoom) {
		int size = hotelRooms.size();
		hotelRooms.add(hotelRoom);
		if (hotelRooms.size() == (size + 1))
			return true;
		return false;
	}

	public ArrayList<HotelRoom> enterAvailableRooms(ArrayList<HotelRoom> hotelRooms) {
		ArrayList<HotelRoom> availableRooms = new ArrayList<>();
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (hotelRooms.get(i).getCustomers() == null) {
				availableRooms.add(hotelRooms.get(i));
			}
		}
		for (int i = 0; i < availableRooms.size(); i++) {
			if (availableRooms.get(i).getCustomers() != null) {
				availableRooms.remove(i);
			}
		}
		return availableRooms;
	}

	public ArrayList<HotelRoom> enterUnavailableRooms(ArrayList<HotelRoom> hotelRooms) {
		ArrayList<HotelRoom> unavailableRooms = new ArrayList<HotelRoom>();
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (hotelRooms.get(i).getCustomers() != null) {
				unavailableRooms.add(hotelRooms.get(i));
			}
		}
		for (int i = 0; i < unavailableRooms.size(); i++) {
			if (unavailableRooms.get(i).getCustomers() == null) {
				unavailableRooms.remove(i);
			}
		}
		return unavailableRooms;
	}

	public void editAHotelRoom(ArrayList<HotelRoom> hotelRooms, HotelRoom hotelRoom) {
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (hotelRoom.getIdRoom() == hotelRooms.get(i).getIdRoom()) {
				hotelRooms.get(i).setTypeRoom(hotelRoom.getTypeRoom());
				hotelRooms.get(i).setNumberOfDaysRented(hotelRoom.getNumberOfDaysRented());
				hotelRooms.get(i).setNumberOfPeople(hotelRoom.getNumberOfPeople());
				hotelRooms.get(i).setPrice(hotelRoom.getPrice());
			}
		}
	}

	public void editCustomer(ArrayList<Customer> customers, Customer customer) {
		for (int i = 0; i < customers.size(); i++) {
			if (customer.getPerson().getIdentifyCard() == customers.get(i).getPerson().getIdentifyCard()) {
				customers.get(i).setPerson(customer.getPerson());
			}
		}
	}

	public boolean deleteCustomer(ArrayList<Customer> customers, int identifyCard) {
		boolean flag = false;
		for (int i = 0; i < customers.size(); i++) {
			if (identifyCard == customers.get(i).getPerson().getIdentifyCard()) {
				customers.remove(i);
				flag = true;
			}
		}
		return flag;
	}

	public boolean deleteAHotelRoom(ArrayList<HotelRoom> hotelRooms, int idRoom) {
		boolean flag = false;
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (idRoom == hotelRooms.get(i).getIdRoom()) {
				hotelRooms.remove(i);
				flag = true;
			}
		}
		return flag;
	}

	@Override
	public boolean checkInRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> availableRooms, int idRoom) {
		ArrayList<Customer> customers = new ArrayList<Customer>();
		boolean flag = false;
		for (int i = 0; i < availableRooms.size(); i++) {
			if (idRoom == availableRooms.get(i).getIdRoom()) {
				customers = view.enterCustomers(idRoom);
				availableRooms.get(i).setCustomers(customers);
				availableRooms.get(i).setStatus("Unavailable!");
				flag = true;
			}
		}
		for (int j = 0; j < hotelRooms.size(); j++) {
			if (hotelRooms.get(j).getIdRoom() == idRoom) {
				hotelRooms.get(j).setCustomers(customers);
				hotelRooms.get(j).setStatus("Unavailable!");

			}
		}
		return flag;
	}

	@Override
	public boolean checkOutRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> unavailableRoom, int idRoom) {
		boolean flag = false;
		for (int i = 0; i < unavailableRoom.size(); i++) {
			if (idRoom == unavailableRoom.get(i).getIdRoom()) {
				unavailableRoom.get(i).setCustomers(null);
				unavailableRoom.get(i).setStatus(null);
				flag = true;
			}
		}
		for (int i = 0; i < hotelRooms.size(); i++) {
			if (hotelRooms.get(i).getIdRoom() == idRoom) {
				hotelRooms.get(i).setCustomers(null);
				hotelRooms.get(i).setStatus("Available!");
			}
		}
		return flag;
	}
}
