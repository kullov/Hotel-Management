package nga.imp;

import java.util.ArrayList;

import nga.entity.HotelRoom;

public interface ImDealsHotel {
	public boolean checkInRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> availableRoom, int idRoom);

	public boolean checkOutRoom(ArrayList<HotelRoom> hotelRooms, ArrayList<HotelRoom> unavailableRoom, int idRoom);
}
