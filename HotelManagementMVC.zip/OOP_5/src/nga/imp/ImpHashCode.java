package nga.imp;

public interface ImpHashCode {
	public static int CASE_ADD_NEW_ROOM = 1;
	public static int CASE_SHOW_LIST_OF_HOTEL_ROOMS = 2;
	public static int CASE_SHOW_A_ROOM = 3;
	public static int CASE_CHECKIN = 4;
	public static int CASE_CHECKOUT = 5;
	
	public static int CASE_ADD_A_ROOM = 21;
	public static int CASE_DELETE_A_ROOM = 22;
	public static int CASE_EDIT_A_ROOM = 23;
	public static int CASE_EXIT = 0;
	
	public static int CASE_SHOW_LIST_OF_CUSTOMERS = 31;
	public static int CASE_ADD_A_CUSTOMER = 32;
	public static int CASE_DELETE_A_CUSTOMER = 34;
	public static int CASE_EDIT_A_CUSTOMER = 35;

	public static int CASE_SHOW_LIST_OF_AVAILABLE_ROOM = 41;
	public static int CASE_CHECKIN_A_ROOM = 42;
	public static int CASE_SHOW_LIST_OF_UNAVAILABLE_ROOM = 43;
	
}
